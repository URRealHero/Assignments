#include "SQList.h"

void swap(ElemType &x, ElemType &y){
  int tmp;
  tmp = x;
  x = y ; 
  y = tmp;
}
